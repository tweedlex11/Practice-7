package com.example

import com.example.models.Task
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.server.testing.*
import kotlin.test.*

class ApplicationTest {

    @Test
    fun testGetTasks() = testApplication {
        val response = client.get("/tasks")
        assertEquals(HttpStatusCode.OK, response.status)
    }

    @Test
    fun testPostTask() = testApplication {
        val response = client.post("/tasks") {
            contentType(ContentType.Application.Json)
            setBody(Task(id = 1, title = "Learn Ktor", completed = false))
        }
        assertEquals(HttpStatusCode.Created, response.status)
    }
}
