package com.example.routes

import com.example.models.Task
import com.example.services.TaskService
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Route.taskRoutes() {

    route("/tasks") {

        // GET /tasks — повертає всі завдання
        get {
            call.respond(TaskService.getAll())
        }

        // GET /tasks/{id} — повертає одне завдання по ID
        get("/{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            if (id == null) {
                call.respondText("Invalid ID", status = HttpStatusCode.BadRequest)
                return@get
            }

            val task = TaskService.getById(id)
            if (task == null) {
                call.respondText("Task not found", status = HttpStatusCode.NotFound)
            } else {
                call.respond(task)
            }
        }

        // POST /tasks — додає нове завдання
        post {
            try {
                val task = call.receive<Task>()
                TaskService.addTask(task)
                call.respondText("Task added successfully!", status = HttpStatusCode.Created)
            } catch (e: Exception) {
                call.respondText("Invalid data format", status = HttpStatusCode.BadRequest)
            }
        }
    }
}
