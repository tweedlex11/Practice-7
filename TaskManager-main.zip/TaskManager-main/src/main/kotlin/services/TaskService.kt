package com.example.services

import com.example.models.Task

object TaskService {
    private val tasks = mutableListOf<Task>()

    fun getAll(): List<Task> = tasks

    fun getById(id: Int): Task? = tasks.find { it.id == id }

    fun addTask(task: Task) {
        tasks.add(task)
    }
}
