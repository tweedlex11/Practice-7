rootProject.name = "TaskManager"

dependencyResolutionManagement {
    repositories {
        mavenCentral()
    }
}
